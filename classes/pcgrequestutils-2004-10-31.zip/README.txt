This class is used througout the PCG Framework to get all data from Form. 

Code Generated from phpCodeGenie (PCG) automatically uses the RequestUtils
to get all user Data from form.

For more information, check the phpCodeGenie webpage on Sourceforge 

http://phpcodegenie.sourceforge.net/

Extract taken from the PCG Framework OverView Manual about Request Utils

Dealing with User Input using requestUtils

User input in a web application is done via HTML forms. 

PHP provides the $_POST, $_GET and $_REQUEST global variables to retrieve data from html forms 
directly.

Retrieving the data directly from these global variables could cause a security threat in your 
application though.

One can never trust user input. There can be malicious users trying to do Cross Site Scripting (XSS) 
or SQL injections hack by messing with the data. Therefore, one need to be parse the data and make
sure it is safe before passing it to your application. An example of an XSS attack would be :

e.g Let say you have a text field element, which you allow user to input data and then your display
the input data, the user could put something like

  <script> (for ;;) { alert(�hacked�); </script> 
  
in the input text and on displaying the input data, your page would go in a infinite loop asking
the user to press on a javascript alert box forever.


Another common problem with user input is magic_quotes is turned on or off. 
When magic_quotes is turned on in your php, some characters are automatically escaped. 
While you might have it enabled on your server, you are not sure that all servers you 
are going to deploy your application to, will have the same settings. So you need to 
make sure that, you check for whether its enabled or not on the server that your application
runs on and escape your user data accordingly. It would be a big hassle to check for 
whether magic quotes is on or off each time you get a a user input. 

PCG solves these two above problems by using the requestUtils class to get form elements. 
By using a separate class to do the form retrieval, it puts that action in one central place
and easy to change. So in that class, you can add whatever sanity check you need to make. 
Currently, the requestUtils::getRequestObject($elementName) method ltrim and rtrim your input 
data, strip the html tags (this setting is configurable in applicationConstants.inc.php, 
by setting the ALLOW_HTML_TAGS_IN_POST_GET_REQUESTS constant to true or false) and if 
magic_quotes is not enabled, addslashes to the data before returning to the client.
 
 
Usage example

Let�s say you have a form

HTML FORM
<FORM NAME=�nileshForm� METHOD=�POST� ACTION=�test.php�>
UserInput : <input type=�text� name=�userInput� value=��>
</FORM>

Instead of using <? $thisUserInput = $_POST[�userInput�]; ?> to get that form element, we will use the code below. It will perform the same action as using the $_POST, but it will also do sanity check on the data input by user. You can add your own additional sanity checks to the getRequestObject method if you need to in one central place.

PHP SCRIPT
<?
	$thisUserInput = requestUtils::getRequestObject('userInput');
?>
