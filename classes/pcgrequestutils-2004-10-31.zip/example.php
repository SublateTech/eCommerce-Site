<?

include_once("requestUtils.class.php");

// userData is an HTML form element 
// instead of using $_REQUEST or $_POST or $_GET['userData']
// we'll use the requestUtils Class to do so

// RequestUtils will sanitize the userData before passing to your application

$sanitizedUserData = requestUtils::getRequestObject('userData');

?>

User Data was : <? echo $sanitizedUserData; ?>