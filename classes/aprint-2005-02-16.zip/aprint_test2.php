<?
/*
 * Aprint test module
 */
require_once('aprint.php');
$p=new aprint("test_2","aprint_test1.php-2.1.0");

$p->SetMargin(2880,1400,1200);
$p->HeaderText("test_2");
for($i=0;$i<50;$i++)
   $p->Text("row:".$i);

// $p->Text("iiiii iiii");
// $p->Text("mmmmm mmmm");
$p->run();
?>
