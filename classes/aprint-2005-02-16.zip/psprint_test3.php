<?
/*
 * Psprint test module
 * $Header: d:\cvs/classistd/aprint/psprint_test3.php,v 1.3 2005/02/13 21:02:40 Darvin Exp $
 */
require_once('psprint.php');
// Class setup. I set the title for the job

$p=new psprint("test_3","aprint_test3.php-1.2.0");


$p->SetPageSize('A5',AP_PORTRAIT);
$p->OpenFileName('test3.ps');
// Margins setup: top, bottom, and left
$p->SetMargin(100,100,1200);
// Create the font to use for the header.
// Two fonts: one big, one normal
// $fnt1=$p->CreateFont("z003034l",720,360,800);
$fnt1=$p->CreateFont("bchr",720,360,800);
$fnt2=$p->CreateFont("Dustismo",360,180,400);
/* Now setup the header.
 * First array, the header is made by 3 rows,
 * Second array the font to use to each row.
 * I want use the big font for the first and third row.
 */
$p->SetPageHeader(array("This is a simple",
                     "text used to test",
                     "the header"),
               array($fnt1,$fnt2,$fnt1)      // different font foe each row
               );
// Draw some text
for($i=0;$i<50;$i++)
   $p->Text("row:".$i);
// Close the page
$p->run();
?>
