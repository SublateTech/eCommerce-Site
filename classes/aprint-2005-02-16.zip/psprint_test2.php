<?
/*
 * Psprint test module
 * This test write so many row to fill one page and to skip to the second one
 * $Header: d:\cvs/classistd/aprint/psprint_test2.php,v 1.2 2005/02/13 20:29:29 Darvin Exp $
 */
require_once('psprint.php');
$p=new psprint("test_2","aprint_test1.php-2.1.0");
$p->SetPageSize('A4',AP_PORTRAIT);
$p->OpenFileName('test2.ps');
$p->SetMargin(2880,1400,1200);
$p->HeaderText("test_2");
for($i=0;$i<50;$i++)
   $p->Text("row:".$i);
$p->run();
?>
