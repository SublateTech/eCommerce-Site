<?php
  /**
   * PSPrint.php
   *
   * Simple class for printing text (PostScript version)   
   * @author Andrioli Darvin
   * @version $Header: d:\cvs/classistd/aprint/psprint.php,v 1.4 2005/02/13 21:02:39 Darvin Exp $
   *
   * @copyright 
   *   Copyright (C) 2005  Andrioli Darvin <darvin@andrioli.com>
   *
   *   This library is free software; you can redistribute it and/or
   *   modify it under the terms of the GNU Lesser General Public
   *   License as published by the Free Software Foundation; either
   *   version 2 of the License, or (at your option) any later version.
   *
   *   This library is distributed in the hope that it will be useful,
   *   but WITHOUT ANY WARRANTY; without even the implied warranty of
   *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   *   Lesser General Public License for more details.
   *
   *   You should have received a copy of the GNU Lesser General Public
   *   License along with this library; if not, write to the Free Software
   *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307  USA
   *
   */

require_once('aprint.php');

/**
 * Paper Orientation
 * @const AP_LANDSCAPE
 * @access public
 */
define('AP_LANDSCAPE',0);
/**
 * Paper Orientation
 * @const AP_PORTRAIT
 * @access public
 */
define('AP_PORTRAIT',1);

/**
* 
*
*/
class PSPrint extends APrint {

/**
* File Postscript to write
*
* @var string
*/
var $FileName;
/**
* Document handler
*
* @var resource
*/
var $hDoc;
/**
 * Paper orientation, supported only by ps module
 * @var integer
 */
var $Orientation;
/**
 * Is the page size set?
 * @var boolean
 */
var $IsSizeSet;
/**
 * Space between two rows
 * @var integer
 */
var $Interlinea;
/**
 * Path to fonts file
 * @var array
 */
var $FontPath;
/**
* Initialize this class. It does not attempt to
* open the output file
* This class will perform this job at the first time that you send any text
* @param string $TitleText document title
* @param string $ScriptId script identification
* @access public
*/
function PSPrint($TitleText="",$ScriptId="") {
APrint::APrint($TitleText,$ScriptId);    
$this->FileName=""; 
$this->IsSizeSet=false;
$this->CurrentFont=AP_NORMAL_FONT;

// Margins default settings
$this->MarginTop=400;
$this->MarginBottom=400;
$this->MarginLeft=40;
$this->MarginRight=40;
$this->Interlinea=5;

$this->FontPath=array('.');
}

/**
 * The Aprint module take the page size from the printer. Here the user must provide the 
 * page size
 * Unit used: twip,
 * 1 inch = 1440 twip
 * 1 mm = 56.7 twip
 * @access private
 * @see SetPageSize()
 * @see SetCustomPageSize()
 */
function _DefinePageSize()
{
}

/**
 * The page size. This function accept the well known page forms
 * LEGAL,LETTER, A3,A4,A5, B4, B5
 * @param string
 * @access public
 * @see SetCustomPageSize()
 */
function SetPageSize($PageType='A4',$orientation)
{
switch($PageType)
  {
  case 'LETTER':
       $this->PaperDimX=8.5*1440;
       $this->PaperDimY=11*1440;
       break;
  case 'LEGAL':
       $this->PaperDimX=8.5*1440;
       $this->PaperDimY=14*1440;
       break;
  case 'A3':
       $this->PaperDimX=297*56.7;
       $this->PaperDimY=420*56.7;
       break;
  case 'A4':
       $this->PaperDimX=8*1440;
       $this->PaperDimY=11.69*1440;
       break;
  case 'A5':
       $this->PaperDimX=148*56.7;
       $this->PaperDimY=210*56.7;
       break;
  case 'B4':
       $this->PaperDimX=250*56.7;
       $this->PaperDimY=354*56.7;
       break;
  case 'B5':
       $this->PaperDimX=182*56.7;
       $this->PaperDimY=257*56.7;
       break;
  default:  // Unknown format, use A4
       $this->PaperDimX=8.27*1440;
       $this->PaperDimY=11.69*1440;
       break;
  }
$this->Orientation=$orientation;
$this->IsSizeSet=true;
$this->_CheckMarginValue();
}

/**
 * Set custom page size. The dimension must be points.
 * 1 inch = 1440 points
 * 1 mm = 56.7 twip
 * @param integer
 * @param integer
 * @param integer
 * @see AP_PORTRAIT
 * @see AP_LANDSCAPE
 * @access public
 */
function SetCustomPageSize($DimX,$DimY,$Orientation)
{
$this->PaperDimX=$DimX;
$this->PaperDimY=$DimY;    
$this->IsSizeSet=true;
$this->Orientation=$Orientation;
$this->_CheckMarginValue();
}

/**
 * Useful function to setup all margins with one function
 * use -1 to skip the parameter
 *
 * @param integer $top top margin size
 * @param integer $bottom bottom margin size
 * @param integer $left left margiclass
 * @param integer $right right margin size
 * @access public
 */

function SetMargin($top,$bottom=-1,$left=-1,$right=-1)
{
APrint::SetMargin($top,$bottom,$left,$right);
$this->row=$this->MarginTop;
}

/**
 * Set the size for the top margin
 * @param integer
 * @access public
 */
function SetTopMargin($value)
{
APrint::SetTopMargin($value);
$this->row=$this->MarginTop;
}
/**
 * Check the value for the margin. They should be >0 and
 * less then the page size. The PSPrint version, before to call the APrint method
 * check whether the page size is set.
 *
 * @access private
 */
function _CheckMarginValue()
{
if(!$this->IsSizeSet)
   trigger_error('Set the page size before to set the margins size',E_USER_ERROR);
APrint::_CheckMarginValue();   
}
/**
 * Specify which printer I'll use. PSPrint does not use any printer, but 
 * write its content into file, therefore this function is meaningless. Call
 * SetFileName instead. It exists to avoid to broke the interface.
 * @param string $Name printer name as defined in Window
 * @access public $Name
 * @return void
 * @see SetFileName()
 */
function SetPrinter($Name)
{
APrint::SetPrinter($Name);  
$this->FileName=$Name;
}

/**
 * Set the name of the file to write
 * @param string $Name
 * @access public
 * @return void
 */
function SetFileName($Name)
{
APrint::SetPrinter($Name);  
$this->FileName=$Name;
}

/**
 * printout the text
 * @param string $text text to printout
 * @param integer $hFont Handle to the font to use. Handle returned by CreateFont. If set to -1 
 *                       or not provided, it use the last used font.
 * @param integer $align text alignment
 * @param integer $col Orizontal position where start to print the text. This value
 *                     will be added to the left margin.
 * @access public
 * @see CreateFont()
 * @see TextFooter()
 */
function Text($text,$hFont=-1,$align=AP_LEFT,$col=0)
{
if(!$this->IsSizeSet)
   trigger_error('Set the page size before write some text',E_USER_ERROR);    
if(!$this->ConnectionOpened) $this->_OpenPrinter();
// Select new font?
if($hFont!=-1)
   {
   $this->_SetFont($hFont);
   }
$size=ps_string_geometry($this->hDoc,$text);
$txtHeight=abs($size['descender'])+$size['ascender'];
if($txtHeight>0)
  $this->FontH=$this->Conv2Twip_y($txtHeight+$this->Interlinea);
$textWidth=$this->Conv2Twip_x($size['width']);
$StartCol=$this->_BeginCol($align,$textWidth,$col);
$this->row+=$this->FontH;
if($this->row>($this->PaperDimY-$this->MarginBottom-300-$this->FontH)&&$this->AutoNewPage)
  {
  $this->NewPage();
  $this->row+=$this->FontH;
  }
ps_show_xy($this->hDoc,$text,$this->ResConv_x($StartCol),$this->_VPoint($this->ResConv_y($this->row)));  
}

/**
 * printout the text at the exact position requested
 * @param integer orizontal position
 * @param integer vertical position where print the text
 * @param string $text text to printout
 * @param integer $hFont Handle to the font to use. Handle returned by CreateFont
 * @access public
 * @see CreateFont()
 * @see Text()
 */
function TextXY($Xpos,$Ypos,$text,$hFont=-1)
{
if(!$this->IsSizeSet)
   trigger_error('Set the page size before write some text',E_USER_ERROR);        
if(!$this->ConnectionOpened) $this->_OpenPrinter();
// Select new font?
if($hFont!=-1)
   {
   $this->_SetFont($hFont);
   }
$size=ps_string_geometry($this->hDoc,$text);
$txtHeight=abs($size['descender'])+$size['ascender'];
if($txtHeight>0)
  $this->FontH=$this->Conv2Twip_y($txtHeight+$this->Interlinea);
$textWidth=$this->Conv2Twip_y($size['width']);
$this->row=$Ypos+$this->FontH;
if($this->row>($this->PaperDimY-$this->MarginBottom-300-$this->FontH)&&$this->AutoNewPage)
  {
  $this->NewPage();
  $this->row=$Ypos+$this->FontH;
  }
ps_show_xy($this->hDoc,$text,$this->ResConv_x($Xpos),$this->_VPoint($this->ResConv_y($Ypos)));  
}

/**
 * Print the page header
 * @access public
 * @see Text()
 */
function PrintPageHeader()
{
if(!$this->ConnectionOpened) $this->_OpenPrinter();
$OriginalFont=-1;
foreach($this->NewPageHeader as $Value)
  {
  	
  $Text=$Value['Text'];
  $hFont=$Value['Font'];
  if($hFont!=-1 && $hFont!="")
     {
     $oldFont=$this->_SetFont($hFont);
     }
   if($OriginalFont<0) $OriginalFont=$oldFont;   
   $size=ps_string_geometry($this->hDoc,$Text);
   $txtHeight=$this->Conv2Twip_y(abs($size['descender'])+$size['ascender']+$this->Interlinea);
   if($txtHeight>0)
      $FontH=$txtHeight;
   $textWidth=$this->Conv2Twip_x($size['width']);

   $StartCol=$this->_BeginCol(AP_LEFT,$textWidth,0);   
   $this->row+=$FontH;   
   ps_show_xy($this->hDoc,$Text,$this->ResConv_x($StartCol),
                     $this->_VPoint($this->ResConv_y($this->row)));
  }  // Loop on each row

if($OriginalFont>-1)
  $this->_SetFont($OriginalFont);
}


/**
 * Print the given text as page footer
 * @param string $text text to printout
 * @param integer $hFont Handle to the font to use. Handle returned by CreateFont
 * @param integer $align text alignment
 * @param integer $col Orizontal position where start to print the text. This value
 *                     will be added to the left margin.
 * @access public
 * @see CreateFont()
 * @see Text()
 */
function TextFooter($text,$hFont=-1,$align=AP_LEFT,$col=0)
{
if(!$this->ConnectionOpened) $this->_OpenPrinter();
// Select new font?
if($hFont!=-1)
   {
   $oldFont=$this->_SetFont($hFont);
   }
else
   {
   $oldFont=$this->_SetFont(AP_FOOTER_FONT);
   }
$size=ps_string_geometry($this->hDoc,$text);
$txtHeight=$this->Conv2Twip_y(abs($size['descender'])+$size['ascender']+$this->Interlinea);
$FontH=$txtHeight;
$textWidth=$this->Conv2Twip_x($size['width']);
$StartCol=$this->_BeginCol($align,$textWidth,$col);
ps_show_xy($this->hDoc,$text,$this->ResConv_x($StartCol),
           $this->_VPoint($this->ResConv_y($this->PaperDimY-$this->MarginBottom)));
                  
ps_end_page($this->hDoc);            
$this->_SetFont($oldFont);
}

/**
* Close the output.
* @access public
*/
function run()
{
$this->_FooterNote();
ps_end_page($this->hDoc);
ps_close($this->hDoc);
ps_delete($this->hDoc);
}

/**
 * Close the current page and start the new one.
 *
 * @access public
 */
function NewPage()
{
if(!$this->IsSizeSet)
   trigger_error('Set the page size before start the new page',E_USER_ERROR);    
if(!$this->ConnectionOpened)
  trigger_error("Open the connection to the printer before run the function NewPage",E_USER_ERROR);
// run the callback, if set
if(array_key_exists('newpage',$this->CallBacks))
  call_user_func_array($this->CallBacks['newpage'],$this->CallBacksParm['newpage']);

if($this->NPag&&$this->PrintPageFooter) {
     $this->_FooterNote();
     }
if($this->NPag) {
   ps_end_page($this->hDoc);
   }
$this->NPag++;
ps_begin_page($this->hDoc,$this->ResConv_x($this->PaperDimX),$this->ResConv_y($this->PaperDimY));
// enable the last used font on the current page
$this->_SetFont();
$this->row=$this->MarginTop;
$this->PrintPageHeader();
}

/**
 * Printout page number and script name as footer
 *
 * @access private
 */
function _FooterNote()
{
$oldFont=$this->_SetFont(AP_FOOTER_FONT);
$size=ps_string_geometry($this->hDoc,$this->ScriptId);
$txtHeight=$this->Conv2Twip_y($size['descender']+$size['ascender']+$this->Interlinea);
ps_show_xy($this->hDoc,$this->ScriptId,
           $this->ResConv_x($this->MarginLeft),
           $this->_VPoint($this->ResConv_y($this->PaperDimY-$this->MarginBottom)));
$size=ps_string_geometry($this->hDoc,$this->NPag);
// $txtHeight=$size['descender']+$size['ascender']*$this->Res_Y;           
$width=$this->Conv2Twip_x($size['width']);
ps_show_xy($this->hDoc,$this->NPag,
           $this->ResConv_x($this->PaperDimX-$this->MarginRight-$width),
           $this->_VPoint($this->ResConv_y($this->PaperDimY-$this->MarginBottom)));
$this->_SetFont($oldFont);
}

/**
* Create new font
*
* @param string $fName Font Name. Set the path to the font file. The ps extension
*                                 should take the path from the function set_pathname, but
*                                 on my system it doesn't work (ps 1.3.0 + pslib 0.2.5). So I must
*                                 provide here the full pathname (absolute or relative) to the font file
* @param integer $fHeight Font height, default: 336
* @param integer $fWidth Font width, default: 168 (PsPrint unused)
* @param integer $fWeight Font weight, default: 400. 0 -> thin, 800 -> bold (PsPrint unused)
* @param boolean $fItalic Italic script? True/False (PsPrint unused)
* @param boolean $fUnderline Text with underline? True/False
* @param boolean $fStrikeout True/False (PsPrint unused)
* @param integer $fOrientation Should be always 3 digits, i.e 020. See printer_create_font in the note to the manual (PsPrint unused)
* @see _SetFont()
* @see Text()
* @see SetFontPath()
* @access public
*
*/
function CreateFont($fName="Courier",$fHeight=240,$fWidth=120,$fWeight=400,$fItalic=false,$fUnderline=false,$fStrikeout=false,$fOrientaton=0)
{
if(!$this->ConnectionOpened)
  trigger_error("Open the output file before define the font",E_USER_ERROR);
$LastFontId=count($this->FontTable);
$this->FontTable[$LastFontId]['fontName']=$fName;
$this->FontTable[$LastFontId]['fontHeight']=ceil($fHeight/20);
$this->FontTable[$LastFontId]['fontWidth']=ceil($fWidth/20);
$this->FontTable[$LastFontId]['fontWeight']=$fWeight;
$this->FontTable[$LastFontId]['fontItalic']=$fItalic;
$this->FontTable[$LastFontId]['fontUnderline']=$fUnderline;
$this->FontTable[$LastFontId]['fontStrikeout']=$fStrikeout;
$this->FontTable[$LastFontId]['fontOrientaton']=$fOrientaton;
// if(!$this->FontTable[$LastFontId]['fontHandler'] = ps_findfont($this->hDoc, $this->FontTable[$LastFontId]['fontName'], "builtin", 1))
if(!$this->FontTable[$LastFontId]['fontHandler'] = ps_findfont($this->hDoc, $this->FontTable[$LastFontId]['fontName'], "", 0))

   trigger_error("Could not find font.\n",E_USER_ERROR);
return($LastFontId);
}

/**
* Open the output printer (APrint) or the output file (PSPrint)
* @access private
* @see OpenFileName()
*/
function _OpenPrinter()
{
if($this->FileName=="")
  trigger_error('Set the filename to open',E_USER_ERROR);
else
  {
   $this->hDoc=ps_new();
   if (!ps_open_file($this->hDoc, $this->FileName)) 
       trigger_error('Error open file '.$this->FileName,E_USER_ERROR);
  }
if($this->Orientation==AP_PORTRAIT)
  ps_set_info($this->hDoc, "Orientation", "Portrait");
else 
  ps_set_info($this->hDoc, "Orientation", "Landscape");
$this->ConnectionOpened=true;
$this->_DefinePageSize();    // inizialize all parameter relate the margins, and page size
$this->Res_X=72;
$this->Res_Y=72;
// set the font path. It must be done after the creation of the new document
for($i=0;$i<count($this->FontPath);$i++)
    ps_set_parameter($this->hDoc,'SearchPath',$this->FontPath[$i]);
$this->_DefaultFont();
$this->NewPage();
$this->_SetFont(AP_NORMAL_FONT);
}


/**
 * Start the connection to the printer. This is the public interface
 * to _OpenPrinter.
 * @param string $FileName Name of the printer to use. If not set use the system default
 * @access public
 * @see _OpenPrinter()
 */
function OpenFileName($FileName="")
{
if($FileName!="") $this->SetPrinter($FileName);
$this->_OpenPrinter();
}

/**
* Activate the specified font
*
* @param int $fnt font handle returned by CreateFont
* @access private
* @see CreateFont()
*/
function _SetFont($fnt=-1)
{
if($fnt==-1)
   $fntHandler=$this->CurrentFont;
else 
   $fntHandler=$fnt;
assert('array_key_exists($fntHandler,$this->FontTable)');
ps_set_parameter($this->hDoc, "underline", $this->FontTable[$fntHandler]['fontUnderline']);   
//ps_set_parameter($ps, "strikeout", $this->FontTable[$LastFontId]['fontStrikeout']);
ps_setfont($this->hDoc, $this->FontTable[$fntHandler]['fontHandler'], $this->FontTable[$fntHandler]['fontHeight']);
$oldFont=$this->CurrentFont;
$this->CurrentFont=$fntHandler;
return($oldFont);
}

/**
 * Set the path where the font file .afm are located. The Postscript module require 
 * Notice: if the ps module is not created, the class store the information until it will be created
 * and then set the given path.
 * The ps extension should take the path from the function set_pathname, but
 * on my system it doesn't work (ps 1.3.0 + pslib 0.2.5). So I must
 * provide here the full pathname (absolute or relative) to the font file as parameter to
 * CreateFont()
 * @access public
 * @param string $Path
 * @see CreateFont()
 */
function SetFontPath($Path)
{
$this->FontPath[]=$Path;
if($this->ConnectionOpened)
   ps_set_parameter($this->hDoc,'SearchPath',$Path);
}

/**
 * Define some dafault font
 * @access private
 */
function _DefaultFont()
{
// create predefined font. Don't change the row order
$this->CreateFont("Dustismo",320,8,400,false,false,false,0);
$this->CreateFont("Dustismo",320,8,800,false,false,false,0);
$this->CreateFont("Dustismo",240,6,200,false,false,false,0);
}

/**
 * The ps module set the point zero to the bottom edge of the page, the
 * module has its point zero on the top edge, the function converts the 
 * vertical value from both systems.
 * @param integer $PosY Vertical position (Aprint system)
 * @return integer Vertical position (Ps system)
 * @access private
 */
function _VPoint($PosY)
{
$SizeY=$this->ResConv_y($this->PaperDimY);    
if($PosY>$SizeY)
  trigger_error('Vertical position out of the page size',E_USER_ERROR);    
return($SizeY-$PosY);  
}

} // end class PSPrint
?>