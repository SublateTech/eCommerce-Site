<?
/*
 * Psprint test module
 * $Header: d:\cvs/classistd/aprint/psprint_test1.php,v 1.2 2005/02/13 20:29:29 Darvin Exp $
 */
require_once('aprint.php');
require_once('psprint.php');

$p=new PSPrint("test_1","psprint_test1.php-1.1.5");
// Set the page size and orientation. This function must be called before to open the output
// file
$p->SetPageSize('A4',AP_PORTRAIT);
// the file to write
$p->OpenFileName('test1.ps');
// Paper margin
$p->SetMargin(3000,100,0,100);
// the title, you may omit it
$p->HeaderText("test_1");
// and now the text.
$p->Text("Left text");
$p->Text("Center text",-1,AP_CENTER);
$p->Text("Right text",-1,AP_RIGHT);
// Set my own font ...
$fnt=$p->CreateFont("Dustismo");
//... and use it
$p->Text("          Some text",$fnt);
// This text use the previuos used font
$p->Text("Some text");
$p->Text("Some text");
$fnt=$p->CreateFont("Dustismo",320,8,200,false,false,false,'900');
$p->Text("          Some text",$fnt);
$p->Text("Some text");
$p->Text("Some text");
$p->BlankRow();
$p->BlankRow();
$p->BlankRow();
$p->BlankRow();
$p->BlankRow();
$p->Text("Some text 90",$fnt);
// that's all!. Close the file and release it!
$p->run();
?>
