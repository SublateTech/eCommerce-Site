
	Pascal CASENOVE
	Independent creator
	pascal@cawete.com
	
	
	Publish usefull things can be a good opportunity to be known.
	I want to participate  in scientifc or tecnical projects.
	My specialty :find solutions,take up challenges.
	If you give that code to someone please put this small resume with it.
	 
	I create and display tools for companies in Europe, the United States and the Caribean Island.
	I also intervene as an expert for insurances companies or for audit or advices to solve problems 
	or help in making decisions.
	 
	I work by distance and\or on site.
	
	I work often on new technologies.
	I set up models for customers or for myself with students or within the framework of researches.
	
	I work in the following fields keeping in mind a global vision of the projects in order to replace 
	one technology by an other more adapted to the specfic project and so have a result as perfect as 
	possible
	
	For all that fields I intervene in the research, the creation of a model or a method, the display 
	and the administration or just for some details of a specific project.
	
	- TCP/IP network architecture
	- Routing, mostly  CISCO and LINUX
	- LAN, WAN, hertzian network security
	- Servers, mostly Microsoft and Linux
	- Servers and sites securizing process
	- Databases, architecture and administration MySQL, SQL, ORACLE �
	- Communication Bridge between databases
	- Realization of interfaces, statement or treatment on existing databases, masters or basics 
	- Citrix and TSE ( many realizations) with or without light customers
	- Small programmes realizations (dos, unix, perl, VB, PHP, JAVA, Javascript ..)
	- Add of functionalities in existing applications, collaborating with the editor or 
		without his participation
	- Realization of small applications such as the administration of financing files,
	  the badging with  transpondeur, the billing, the stocks administration,  the orders preparation�
	- Realization of applications embarqu�es whether by microcontroller whether with Linux, even with 
	  GPRS.
	  For all these realizations I utilize currently the possibilities proposed by the operating 
	  systems that 	allow to do a lot without encoding and also Perl, PHP, Python, JAVA, Windev and 
	  I have done many projects in VBA by MS Access

	I have also designed many tools to create web interfaces mostly in PHP and MySQL.

	I have various PHP CLASS that I will publish after some cleaning and, for some, with my clients 
	agreement.

	I have done a model for an e-business tool using a business administration tool with bases :  
	MySQL, Ms access, interfaces Windev, VBA, PHP and 
	WAP with the entire plateforme including the gateway WAP. 

	- Many other applications, tools, realizations�
	
	My knowledge as an electronician allow me also to create material.
	I work alone or with a team, on full projects or just for pieces.
	
	For some projects I can use the best specialists to work with me or I hire a team 
	for the duration of the project.
	You can contact me to have some advices on a tool, to create, adapt, 
	modify but don�t ask me for basics which is really boring for me.
	
	I developed methods and tools to work on-site or from my office.
	 

	Whether on open projects, on industrial applications, for an advice, some research,a realization  
	or just to find an answer to a determined problem or a technical advice don�t hesitate to contact 
	me.


	
	***************PHP**********************
	
	For PHP I have some working objects but I have to clean them up before publishing them.
	The next ones should be :
	- A parameters coding transmitted by the URL clear for the application.

	- A PHP variables� display in an independant window during the code execution. This
	is a detail but I can�t do without it and I put it it all my realizations.

	I also have stuff more important but too heavy to be published like the creation of a 
	website based only on HTML databases and maskes, a session administration with login, 
	users rights levels, steering towars rights function sections, full tracking of navigations�, 
	creation and administration of HTML scripts from MySQL records.
	I have many other things to share so don�t hesitate� CONTACT ME !!

