<?php

/**
 * @author Dick Munroe <munroe@csworks.com>
 * @copyright copyright (c) Dick Munroe, 2004-2006, All rights reserved.
 * @license http://www.csworks.com/publications/ModifiedNetBSD.html
 * @version 2.0.0
 */

//
// Edit History:
//
//  Dick Munroe munroe@csworks.com 09-Oct-2004
//      Initial Version Created.
//

include_once('dm.DB/class.factory.DB.php') ;

function options(&$theOptions)
{
    if (empty($theOptions['h']))
    {
        $theOptions['h'] = 'localhost' ;
    }

    if (empty($theOptions['d']))
    {
        $theOptions['d'] = 'MySQL' ;
    }

    if (empty($theOptions['p']))
    {
        $theOptions['p'] = '' ;
    }

    $theOptions['d'] = strtolower($theOptions['d']) ;

    if ($theOptions['d'] == 'mysql')
    {
        $theOptions['d'] = dmDB_MySQL ;
    }
    else if ($theOptions['d'] == 'postgresql80')
    {
        $theOptions['d'] = dmDB_PostgreSQL80 ;
    }
    else if ($theOptions['d'] == 'postgresql81')
    {
        $theOptions['d'] = dmDB_PostgreSQL81 ;
    }
    else
    {
        die('Invalid database type') ;
    }
}
?>
