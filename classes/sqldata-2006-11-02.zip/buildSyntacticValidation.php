<?php

/**
 * @author Dick Munroe <munroe@csworks.com>
 * @copyright copyright (c) Dick Munroe, 2004-2006, All rights reserved.
 * @license http://www.csworks.com/publications/ModifiedNetBSD.html
 * @version 2.0.0
 */

//
// Generate the syntatic validation for interfaces built by buildForm.
//
// This was written as part of the writing of an article for the
// OpenVMS Technical Journal.
//
// This program should be run BEFORE buildForm is run as buildForm checks
// for the existance of a validation file.  This allows you to build forms
// without any validation if desired.
//
// My thanks to Chris Sands, the Director of IT at the Florida Democratic
// Party, for permission to submit this program for general use.
//
//	$Author: munroe $
//	$Date: 2006/11/02 16:42:24 $
//
// Edit History:
//
//  Dick Munroe munroe@csworks.com 03-May-2005
//      Initial Version Created
//
//  Dick Munroe munroe@csworks.com 14-Mar-2006
//	Change licensing, reorganize includes.
//
//  Dick Munroe (munroe@csworks.com) 15-Oct-2006
//      Switch to database independent interfaces.
//

$theOptions = getopt("h:p:u:d:") ;

if (count($_SERVER['argv']) < 3)
{
    print("
buildSyntacticValidation [-h hostname] [-u username] [-p password] [-d DBType] tableName databaseName

    Writes a file named \"form.tableName.js\" and renames any existing file of the same
    name to form.tableName.js.old.
") ;
    return 0 ;
}

//
// Unfortunately PHP doesn't do the argv reduction common to all
// other implementations of getopt, so I'm requiring that the
// table and database names be the first two arguments.
//

include_once('SQLData/options.php') ;

$theTableName = $_SERVER['argv'][count($_SERVER['argv']) - 2] ;
$theDatabaseName = $_SERVER['argv'][count($_SERVER['argv']) - 1] ;

if (empty($theTableName))
{
    die('A table name is needed') ;
}

if (empty($theDatabaseName))
{
    die('A database name is needed') ;
}

options($theOptions) ;

$theDB =
    FactoryDB::factory(
        $theOptions['u'],                               // Username
        $theOptions['p'],                               // Password
        $theDatabaseName,                               // Database
        $theOptions['h'],                               // Host
        $theOptions['d']) ;                             // Database Type

//
// Preserve the outfile, if one already exists.
//

$theFileName = sprintf("form.%s.js", ucfirst($theTableName)) ;
$theOldFileName = $theFileName . ".old" ;

if (file_exists($theFileName))
{
  if (is_file($theFileName))
    {
      if (!rename($theFileName, $theOldFileName))
	{
	  exit(1) ;
	}
    }
  else
    {
      exit(2) ;
    }
}

if (!($theStream = @fopen($theFileName, 'w')))
{
  exit(3) ;
}

$theValidResults = array() ;

$theResult = $theDB->describeTable($theTableName) ;

$theEncodeType = "" ;

foreach ($theResult as $theResultArray)
{
    if (!preg_match('/auto_increment/', $theResultArray['Extra']))
    {
        if (preg_match('/blob/', $theResultArray['Type']))
        {
            $theEncodeType = 'enctype="multipart/form-data"' ;
        }

        array_push($theValidResults, $theResultArray) ;
    }
}

//
// Build the javascript validation functions
//

foreach ($theValidResults as $theResultArray)
{
    $theForm[] = sprintf('function validate%s(what)
{
    //
    // Validate %s field value
    //

    if (!isRequired(what))
    {
        return false ;
    }

    return true ;
}

',         ucfirst($theResultArray['Field']),
           $theResultArray['Field']) ;
}

if (fwrite($theStream,implode("", $theForm)) === FALSE)
{
  exit(4) ;
}

exit(0) ;
?>
